export type Connection = { from: string; to: string };
