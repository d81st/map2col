export const ITEMS = [
  { id: "p1", key: "properties", title: "Свойство 1" },
  { id: "p2", key: "properties", title: "Свойство 2" },
  { id: "p3", key: "properties", title: "Свойство 3" },
  { id: "p4", key: "properties", title: "Свойство 4" },
  { id: "o1", key: "options", title: "Опция 1" },
  { id: "o2", key: "options", title: "Опция 2" },
  { id: "o3", key: "options", title: "Опция 3" },
  { id: "o4", key: "options", title: "Опция 4" },
] as const;