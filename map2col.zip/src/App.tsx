import MatchGame from "./matchGame/components/MatchGame";

export default function App() {
  return (
    <div>
      <MatchGame />
    </div>
  );
}
